# Flutter Auth App — Group A Internship Task

## Project Structure

```
flutter_auth_app/
├── lib/
│   ├── main.dart
│   └── screens/
│       ├── login_a_screen.dart       ← Login A (Orange themed)
│       ├── signup_a_screen.dart      ← Signup A (Orange themed)
│       ├── login_b_screen.dart       ← Login B (Minimal black/white)
│       ├── signup_b_screen.dart      ← Signup B (Dark navy themed)
│       ├── forgot_password_screen.dart
│       └── home_screen.dart          ← Dashboard / Home Page
└── pubspec.yaml
```

## Screens Implemented

| Screen | Description |
|---|---|
| Login A | Orange background, email+password, social login (Google/Facebook), forgot password |
| Signup A | Orange background, full name/email/password/confirm fields, social login |
| Login B | Minimal white, username+password, circular social icons (F/G/T), dark button |
| Signup B | Navy themed, avatar upload, email+password, Terms checkbox, Google option |
| Forgot Password | Orange card, email input, sends reset link with SnackBar feedback |
| Home / Dashboard | Categories, banner, popular items grid, hot sales/new arrivals, bottom nav |

## Widgets Used (as required)

- `Scaffold`, `AppBar`
- `Column`, `Row`
- `TextField` (with `obscureText`, `InputDecoration`)
- `ElevatedButton`, `OutlinedButton`, `TextButton`
- `Text`, `Icon`, `IconButton`
- `Container`, `SizedBox`
- `Card` (Level-Up bonus — used throughout)
- `Navigator.push`, `Navigator.pop`, `Navigator.pushReplacement`
- `SingleChildScrollView` (overflow prevention)
- `ListView.builder` (horizontal scrolling categories)
- `GridView.builder` (popular items)
- `Divider`
- `Stack`, `Positioned`

## Navigation Flow

```
LoginA ──→ SignupA ──→ HomeScreen
  │                        ↑
  ├──→ ForgotPassword      │
  │                        │
  └──→ LoginB ──→ SignupB ─┘
```

## How to Run

1. Make sure Flutter SDK is installed: https://flutter.dev/docs/get-started/install
2. Copy the `flutter_auth_app/` folder to your workspace
3. Run:
   ```bash
   cd flutter_auth_app
   flutter pub get
   flutter run
   ```

## Notes

- No real authentication is implemented — buttons navigate directly.
- `Navigator.pushReplacement` used on login/signup success so back button won't return to auth screens.
- Forgot Password shows a SnackBar confirmation instead of actual email sending.
- Home Screen logout button navigates back to Login A.
